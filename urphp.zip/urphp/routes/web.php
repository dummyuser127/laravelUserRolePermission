<?php

use Illuminate\Support\Facades\Route;
use App\Http\Controllers\userController;
use Illuminate\Support\Facades\DB;




//login

Route::get('/', function () {
    if(session('email'))
    {
        return view('dashboard');
    } 
    else
    {
        return view('login');
    }
});


//noaccess






//register
Route::view('register','register');
Route::post('userRegistration',[userController::class,'registerUser']);
Route::get('logOutuser',[userController::class,'logoutuser']);
Route::post('userLogin',[userController::class,'checkUserLogin']);
Route::get('noaccess',function()
{
    return view('noaccess');
});



 Route::group(["middleware"=>['protectedPage']],function()
{
    Route::view('dashboard','dashboard');
    Route::view('support','support');
    Route::view('news','news');
    Route::view('about','about');
    Route::view('user','user');
    Route::view('setting','setting');
    Route::view('contact','contact');
    Route::get('news',[userController::class,'newsPrevent']);
    Route::get('about',[userController::class,'aboutPrevent']);
    Route::get('setting',[userController::class,'settingPrevent']);
    Route::get('contact',[userController::class,'contactPrevent']);    
    Route::get('user',[userController::class,'showtheData']);
    Route::get('support',[userController::class,'supportPrevent']);
    Route::post('updateData/{id}',[userController::class,'updateUserData']);
    Route::post('deleteData/{id}',[userController::class,'deleteUserData']);
    Route::post('checkStatus/{id}',[userController::class,'updateStatus']);
    Route::post('addNewuser',[userController::class,'insertUD']);
    Route::get('news',[userController::class,'newsAct']);


});

