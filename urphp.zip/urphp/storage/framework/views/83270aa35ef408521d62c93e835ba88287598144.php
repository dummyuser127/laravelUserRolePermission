<center>
    <img src="https://img.icons8.com/color/48/000000/behavior-blocker.png" style="width: 100px;height:100px;margin-top:100px;"/>
    <div style="font-size: 4cm;">No Access</div>
    <div style="font-size: 1cm;">You Don't have Permission to visit this page. <br> Ask your Admin to get the access of this page.</div>
</center><?php /**PATH C:\xampp\htdocs\urphp\resources\views/noaccess.blade.php ENDPATH**/ ?>