<?php echo $__env->make('include.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

<link href="https://unpkg.com/tailwindcss@^2/dist/tailwind.min.css" rel="stylesheet">
<link rel="stylesheet" type="text/css" href="https://cdn.datatables.net/1.10.25/css/jquery.dataTables.css">
<link href=" https://jainilsoni1706.github.io/newJASS/v3CSS.css " rel=" stylesheet " >
<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
<script type="text/javascript" charset="utf8" src="https://cdn.datatables.net/1.10.25/js/jquery.dataTables.js"></script>

<style>
  table.dataTable.no-footer
  {
    border-bottom: none!important;
  }
</style>

<div style="margin-top:50px"></div>

<div class="container mx-auto">
    <div class="flex flex-col">
        <div class="w-full">
            <div class="p-4 border-b border-gray-200 shadow">
                <!-- <table> -->
                <table id="dataTable" class="p-4">

                  <button type="button" style="margin-bottom:10px;float:right;" class="btn btn-primary" data-bs-toggle="modal" data-bs-target="#staticBackdrop123">
                    Add new user
                  </button>

                  
                  <div class="modal fade" id="staticBackdrop123" data-bs-backdrop="static" data-bs-keyboard="false" tabindex="-1" aria-labelledby="staticBackdropLabel" aria-hidden="true">
                    <form action="addNewuser" method="POST"> <?php echo csrf_field(); ?>
                    <div class="modal-dialog">
                      <div class="modal-content">
                        <div class="modal-header">
                          <h5 class="modal-title" id="staticBackdropLabel">Add new User</h5>
                          <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                        </div>
                        <div class="modal-body">
                          <label>Name</label>
                              <div style="margin:10px 0px;"></div>
                              <input type="text" class="form-control" name="name"  placeholder="Enter your Name here">
                              <div style="margin:10px 0px;"></div>

                              <label >Email</label>
                              <div style="margin:10px 0px;"></div>
                              <input type="email"  class="form-control" name="email"  placeholder="Enter your Name here">
                              <div style="margin:10px 0px;"></div>

                              <label >Password</label>
                              <div style="margin:10px 0px;"></div>
                              <input type="password"  class="form-control" name="password"  placeholder="Enter your Name here">
                              <div style="margin:10px 0px;"></div>

                              <label >Role</label>
                              <div style="margin:10px 0px;"></div>
                              <select name="userrole" class="form-control" >
                                <option value="Superadmin">Superadmin</option>
                                <option value="Admin">Admin</option>
                                <option value="User">User</option>
                              </select>

                              <div style="margin:10px 0px;"></div>

                              <label >Permissions</label>
                              <div style="margin:10px 0px;"></div>

                              <input value="1" type="checkbox" name="about" id="about">
                              <label for="about">About</label>
                              <br>
                              <input value="1" type="checkbox" name="dashboard" id="dashboard">
                              <label for="dashboard">Dashboard</label>
                              <br>
                              <input value="1" type="checkbox" name="contact" id="contact">
                              <label for="contact">Contact</label>
                              <br>
                              <input value="1" type="checkbox" name="user" id="user">
                              <label for="user">User</label>
                              <br>
                              <input value="1" type="checkbox" name="setting" id="setting">
                              <label for="setting">Setting</label>
                              <br>
                              <input value="1" type="checkbox" name="support" id="support">
                              <label for="support">Support</label>
                              <br>
                              <input value="1" type="checkbox" name="news" id="news">
                              <label for="news">Activity</label>

                              <div style="margin:10px 0px;"></div>

                        </div>
                        <div class="modal-footer">
                          <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Close</button>
                          <button type="submit" class="btn btn-primary">Save</button>
                        </div>
                      </div>
                    </div>
                  </form>
                  </div>
                  




                    <thead class="bg-gray-50">
                        <tr>
                            <th class="p-8 text-xs text-gray-500">
                                ID
                            </th>
                            <th class="p-8 text-xs text-gray-500">
                                Name
                            </th>
                            <th class="p-8 text-xs text-gray-500">
                                Email
                            </th>
                            <th class="p-8 text-xs text-gray-500">
                                A.Status
                            </th>
                            <th class="p-8 text-xs text-gray-500">
                              User Role
                          </th>
                            <th class="px-6 py-2 text-xs text-gray-500">
                                Status
                            </th>
                            <th class="px-6 py-2 text-xs text-gray-500">
                                Edit
                            </th>
                            <th class="px-6 py-2 text-xs text-gray-500">
                                Delete
                            </th>
                        </tr>
                    </thead>
                    <tbody class="bg-white">
                        <?php $__empty_1 = true; $__currentLoopData = $userData; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $wholeData): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                        <tr class="whitespace-nowrap">
                            <td class="px-6 py-4 text-sm text-center text-gray-500" style="font-size:20px;">
                                <?php echo e($wholeData->id); ?>

                            </td>
                            <td class="px-6 py-4 text-center">
                                <div class="text-sm text-gray-900" style="font-size:20px;">
                                    <?php echo e($wholeData->name); ?>

                                </div>
                            </td>
                            <td class="px-6 py-4 text-center">
                                <div class="text-sm text-gray-500" style="color: black;font-size:20px;"><?php echo e($wholeData->email); ?></div>
                            </td>
                            <td class="px-6 py-4 text-sm text-center text-gray-500">
                                <?php if($wholeData->status == 1): ?>
                                <span class="text-xs inline-block py-1 px-2.5 leading-none text-center whitespace-nowrap align-baseline font-bold bg-green-500 text-white rounded">Active</span>
                                <?php else: ?>
                                <span class="text-xs inline-block py-1 px-2.5 leading-none text-center whitespace-nowrap align-baseline font-bold bg-red-600 text-white rounded">InActive</span>
                                <?php endif; ?>
                            </td>
                            <td class="px-6 py-4 text-center">
                              <span class="text-xs inline-block py-1 px-2.5 leading-none text-center whitespace-nowrap align-baseline font-bold bg-gray-800 text-white rounded"><?php echo e($wholeData->userrole); ?></span>
                            </td>
                            <td class="px-6 py-4 text-center">
                              <button type="button" class="btn btn-primary" data-bs-toggle="modal" data-bs-target="#exampleModal<?php echo e($wholeData->id); ?>">
                                Change
                              </button>
                            </td>
                            <td class="px-6 py-4 text-center">
                              <button type="button" class="btn btn-warning" data-bs-toggle="modal" data-bs-target="#staticBackdropx<?php echo e($wholeData->id); ?>">
                                Update
                              </button>
                            </td>
                            <td class="px-6 py-4 text-center">
                              <button type="button" class="btn btn-danger" data-bs-toggle="modal" data-bs-target="#exampleModal2<?php echo e($wholeData->id); ?>">
                                Delete
                              </button>  
                            </td>
                            </td>
                        </tr>

                      
                      <div class="modal fade" id="exampleModal<?php echo e($wholeData->id); ?>" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true">
                        <form action="checkStatus/<?php echo e($wholeData->id); ?>" method="POST"><?php echo csrf_field(); ?>
                        <div class="modal-dialog">
                          <div class="modal-content">
                            <div class="modal-header">
                              <h5 class="modal-title" id="exampleModalLabel">Change Status of <?php echo e($wholeData->name); ?></h5>
                              <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                            </div>
                            <div class="modal-body">
                              Are you sre that you wanna change the <strong> <?php echo e($wholeData->name); ?>'s </strong> stauts?
                            </div>
                            <div class="modal-footer">
                              <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Close</button>
                              <button type="submit" class="btn btn-primary">Change</button>
                            </div>
                          </div>
                        </div>
                      </form>
                      </div>
                      





                      
                      <div class="modal fade" id="staticBackdropx<?php echo e($wholeData->id); ?>" data-bs-backdrop="static" data-bs-keyboard="false" tabindex="-1" aria-labelledby="staticBackdropLabel" aria-hidden="true">
                        <form action="updateData/<?php echo e($wholeData->id); ?>" method="POST"> <?php echo csrf_field(); ?>
                          <div class="modal-dialog">
                            <div class="modal-content">
                            <div class="modal-header">
                              <h5 class="modal-title" id="staticBackdropLabel">Update Information of <?php echo e($wholeData->name); ?></h5>
                              <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                            </div>
                            <div class="modal-body">
                              <label for="updateName">Name</label>
                              <div style="margin:10px 0px;"></div>
                              <input type="text" id="updateName" class="form-control" name="name" value="<?php echo e($wholeData->name); ?>" placeholder="Enter your Name here">
                              <div style="margin:10px 0px;"></div>

                              <label for="updateEmail">Email</label>
                              <div style="margin:10px 0px;"></div>
                              <input type="email" id="updateEmail" disabled class="form-control" name="email" value="<?php echo e($wholeData->email); ?>" placeholder="Enter your Name here">
                              <div style="margin:10px 0px;"></div>

                              <label for="updateRole">Role</label>
                              <div style="margin:10px 0px;"></div>
                              <select id="updateRole" name="userrole" class="form-control" >
                                <option value="" disabled selected> <?php echo e($wholeData->userrole); ?> </option>
                                <option value="Superadmin">Superadmin</option>
                                <option value="Admin">Admin</option>
                                <option value="User">User</option>
                              </select>
                              
                              
                              <label >Permissions</label>
                              <div style="margin:10px 0px;"></div>

                              <input value="1" type="checkbox" name="dashboard" id="dashboard1" <?php if($wholeData->dashboard == 1): ?> checked <?php else: ?> <?php endif; ?> >
                              <label for="dashboard1">Dashboard</label>
                              <br>

                              <input value="1" type="checkbox" name="about" id="about1" <?php if($wholeData->about == 1): ?> checked <?php else: ?> <?php endif; ?> >
                              <label for="about1">About</label>
                              <br>
                              <input value="1" type="checkbox" name="contact" id="contact1" <?php if($wholeData->contact == 1): ?> checked <?php else: ?> <?php endif; ?> >
                              <label for="contact1">Contact</label>
                              <br>
                              <input value="1" type="checkbox" name="user" id="user1"  <?php if($wholeData->user == 1): ?> checked <?php else: ?> <?php endif; ?> >
                              <label for="user1">User</label>
                              <br>
                              <input value="1" type="checkbox" name="setting" id="setting1"  <?php if($wholeData->setting == 1): ?> checked <?php else: ?> <?php endif; ?> >
                              <label for="setting1">Setting</label>
                              <br>
                              <input value="1" type="checkbox" name="support" id="support1"  <?php if($wholeData->support == 1): ?> checked <?php else: ?> <?php endif; ?> >
                              <label for="support1">Support</label>
                              <br>
                              <input value="1" type="checkbox" name="news" id="news1"  <?php if($wholeData->news == 1): ?> checked <?php else: ?> <?php endif; ?> >
                              <label for="news1">Activity</label>
                              <div style="margin:10px 0px;"></div>

                              
                              <div style="margin:10px 0px;"></div>
                            </div>
                            <div class="modal-footer">
                              <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Close</button>
                              <button type="submit" class="btn btn-primary">Update</button>
                            </div>
                          </div>
                        </div>
                      </form>
                      </div>
                      








                    
                    <div class="modal fade" id="exampleModal2<?php echo e($wholeData->id); ?>" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true">
                      <form action="deleteData/<?php echo e($wholeData->id); ?>" method="POST"> <?php echo csrf_field(); ?>
                      <div class="modal-dialog">
                        <div class="modal-content">
                          <div class="modal-header">
                            <h5 class="modal-title" id="exampleModalLabel">Delete user <?php echo e($wholeData->name); ?></h5>
                            <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                          </div>
                          <div class="modal-body">
                            Are you sure that you wanna delete the user <strong> <?php echo e($wholeData->name); ?> </strong> as a <strong> <?php echo e($wholeData->userrole); ?> </strong> from the Database Permanently?
                          </div>
                          <div class="modal-footer">
                            <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Close</button>
                            <button type="submit" class="btn btn-danger">Delete</button>
                          </div>
                        </div>
                      </div>
                    </form>
                    </div>
                    







                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                        <?php endif; ?>

                    </tbody>
                </table>
            </div>
        </div>
    </div>
</div>

<script>
    $(document).ready(function () {
        $('#dataTable').DataTable();

    });
</script>


<?php echo $__env->make('include.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php /**PATH C:\xampp\htdocs\urphp\resources\views/user.blade.php ENDPATH**/ ?>