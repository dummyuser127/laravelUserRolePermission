<link rel="stylesheet" href="<?php echo e(asset('public/assets/css/myapp.css')); ?>">
<link rel="stylesheet" href="<?php echo e(asset('public/assets/css/tailwind.css')); ?>">
<link rel="stylesheet" href="<?php echo e(asset('public/assets/css/bootstrapcss.css')); ?>">

  <script src="<?php echo e(asset('public/assets/js/tailwind.js')); ?>"></script>
  <script src="<?php echo e(asset('public/assets/js/tailwind2.js')); ?>"></script>
  <script src="<?php echo e(asset('public/assets/js/myapp.js')); ?>"></script>
  <script src="https://cdn.jsdelivr.net/npm/tw-elements/dist/js/index.min.js"></script><?php /**PATH C:\xampp\htdocs\urphp\resources\views/include/footer.blade.php ENDPATH**/ ?>