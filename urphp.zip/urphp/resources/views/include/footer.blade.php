<link rel="stylesheet" href="{{asset('public/assets/css/myapp.css')}}">
<link rel="stylesheet" href="{{asset('public/assets/css/tailwind.css')}}">
<link rel="stylesheet" href="{{asset('public/assets/css/bootstrapcss.css')}}">
{{-- <footer style="position: absolute;bottom: 0px;left: 0px;width: 100%;" class="text-center lg:text-left bg-gray-100 text-gray-600">
    <div class="text-center p-6 bg-gray-200">
      <span>© 2022 Copyright:</span>
      <a class="text-gray-600 font-semibold" href="https://tailwind-elements.com/">Jainil Soni</a>
    </div>
  </footer> --}}
  <script src="{{asset('public/assets/js/tailwind.js')}}"></script>
  <script src="{{asset('public/assets/js/tailwind2.js')}}"></script>
  <script src="{{asset('public/assets/js/myapp.js')}}"></script>
  <script src="https://cdn.jsdelivr.net/npm/tw-elements/dist/js/index.min.js"></script>